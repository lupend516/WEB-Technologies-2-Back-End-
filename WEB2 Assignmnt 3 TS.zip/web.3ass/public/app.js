let editingUserId = null;  

async function fetchUsers() {
  const search = document.getElementById('search').value;
  const sortBy = document.getElementById('sortBy').value;
  const order = document.getElementById('order').value;

  const response = await fetch(`/users?search=${search}&sortBy=${sortBy}&order=${order}`);
  const users = await response.json();

  const tableBody = document.getElementById('user-table');
  tableBody.innerHTML = ''; 

  users.forEach(user => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${user.name}</td>
      <td>${user.age}</td>
      <td>${user.email}</td>
      <td>
        <button onclick="editUser('${user._id}', '${user.name}', '${user.age}', '${user.email}')">Редактировать</button>
        <button onclick="deleteUser('${user._id}')">Удалить</button>
      </td>
    `;
    tableBody.appendChild(row);
  });
}

document.getElementById('user-form').addEventListener('submit', async (event) => {
  event.preventDefault();

  const name = document.getElementById('name').value;
  const age = document.getElementById('age').value;
  const email = document.getElementById('email').value;

  let response;
  if (editingUserId) {
    response = await fetch(`/users/${editingUserId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, age, email })
    });
    editingUserId = null;
  } else {
    response = await fetch('/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, age, email })
    });
  }

  if (response.ok) {
    fetchUsers();
  } else {
    alert('Ошибка при добавлении/редактировании пользователя');
  }

  document.getElementById('name').value = '';
  document.getElementById('age').value = '';
  document.getElementById('email').value = '';
});

function editUser(id, name, age, email) {
  document.getElementById('name').value = name;
  document.getElementById('age').value = age;
  document.getElementById('email').value = email;

  editingUserId = id;
}

async function deleteUser(id) {
  const response = await fetch(`/users/${id}`, { method: 'DELETE' });

  if (response.ok) {
    fetchUsers();
  } else {
    alert('Ошибка при удалении пользователя');
  }
}

function searchUsers() {
  fetchUsers();
}

function sortUsers() {
  fetchUsers();
}

fetchUsers();

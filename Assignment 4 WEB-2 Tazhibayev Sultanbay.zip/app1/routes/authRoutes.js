const express = require("express");
const router = express.Router();
const User = require("../models/User");
const bcrypt = require('bcrypt');
const session = require("express-session");

// Главная страница
router.get("/", (req, res) => {
  res.render("index", { title: "Главная", user: req.session.user });
});

// Регистрация
router.get("/register", (req, res) => {
  res.render("register", { title: "Регистрация" });
});

router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.render("register", { title: "Регистрация", error: "Email уже используется" });

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = new User({ name, email, password: hashedPassword });
    await newUser.save();

    req.session.userId = newUser._id;
    req.session.user = newUser;

    res.redirect("/dashboard");
  } catch (error) {
    res.render("register", { title: "Регистрация", error: "Ошибка регистрации" });
  }
});

// Вход
router.get("/login", (req, res) => {
  res.render("login", { title: "Вход" });
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.render("login", { title: "Вход", error: "Неверный email или пароль" });
    }

    req.session.userId = user._id;
    req.session.user = user;
    res.redirect("/dashboard");
  } catch (error) {
    res.render("login", { title: "Вход", error: "Ошибка входа" });
  }
});

// Личный кабинет
router.get("/dashboard", (req, res) => {
  if (!req.session.userId) return res.redirect("/login");
  res.render("dashboard", { title: "Личный кабинет", user: req.session.user });
});

// Выход
router.get("/logout", (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).send("Ошибка выхода");
    res.redirect("/");
  });
});

// Редактирование профиля
router.get("/edit", async (req, res) => {
  if (!req.session.userId) return res.redirect("/login");

  const user = await User.findById(req.session.userId);
  if (!user) return res.redirect("/login");

  res.render("edit", { title: "Редактировать профиль", user });
});

router.post("/edit", async (req, res) => {
  if (!req.session.userId) return res.redirect("/login");

  const { name, email } = req.body;
  const updatedUser = await User.findByIdAndUpdate(req.session.userId, { name, email }, { new: true });

  req.session.user = updatedUser;

  res.redirect("/dashboard");
});

// Удаление пользователя
router.post("/delete", async (req, res) => {
  if (!req.session.userId) return res.redirect("/login");

  try {
    await User.findByIdAndDelete(req.session.userId);
    req.session.destroy(err => {
      if (err) return res.status(500).json({ error: "Ошибка удаления" });
      res.redirect("/register");
    });
  } catch (error) {
    res.status(500).json({ error: "Ошибка при удалении пользователя" });
  }
});

module.exports = router;

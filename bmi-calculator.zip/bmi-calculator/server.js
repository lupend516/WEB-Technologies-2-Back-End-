// Импортируем модули
const express = require('express');  // Подключаем Express
const path = require('path');        // Модуль для работы с путями

// Создаем сервер
const app = express();
const port = 3000; // Порт, на котором будет работать сервер

// Middleware для обработки данных форм и статических файлов
app.use(express.urlencoded({ extended: true })); // Позволяет читать данные из формы
app.use(express.static(path.join(__dirname, 'public'))); // Подключаем статические файлы (CSS)

// Маршрут для главной страницы "/"
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html')); // Отправляем HTML-файл
});

// Маршрут для обработки формы "/calculate"
app.post('/calculate', (req, res) => {
    // Получаем данные из формы
    const weight = parseFloat(req.body.weight);
    const height = parseFloat(req.body.height);
    const age = req.body.age;
    const gender = req.body.gender;

    // Проверка на корректность ввода
    if (!weight || !height || weight <= 0 || height <= 0 || height >= 2.00) {
        return res.send('Error: Please enter valid positive numbers for weight and height.');
    }

    // Расчет BMI
    const bmi = (weight / (height * height)).toFixed(2);
    let category = '';

    if (bmi < 18.5) category = 'Underweight';
    else if (bmi >= 18.5 && bmi <= 24.9) category = 'Normal weight';
    else if (bmi >= 25 && bmi <= 29.9) category = 'Overweight';
    else category = 'Obesity';

    // Отправляем результат
    res.send(`
        <h1>Your BMI Result</h1>
        <p>BMI: ${bmi}</p>
        <p>Category: ${category}</p>
        <p>Age: ${age}</p>
        <p>Gender: ${gender}</p>
        <a href="/">Go back</a>
    `);
});

// Запуск сервера
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost:27017/assignment3', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const userSchema = new mongoose.Schema({
  name: String,
  age: Number,
  email: String
});

const User = mongoose.model('User', userSchema);

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/users', async (req, res) => {
  try {
    const { search, sortBy, order } = req.query; 
    const filter = search ? { name: new RegExp(search, 'i') } : {};  
    const sortOptions = sortBy ? { [sortBy]: order === 'desc' ? -1 : 1 } : {}; 

    const users = await User.find(filter).sort(sortOptions);
    res.json(users);
  } catch (error) {
    res.status(500).send('Ошибка при получении данных пользователей');
  }
});

app.post('/users', async (req, res) => {
  const { name, age, email } = req.body;
  const newUser = new User({ name, age, email });

  try {
    await newUser.save();
    const users = await User.find(); 
    res.json(users); 
  } catch (error) {
    res.status(500).send('Ошибка при добавлении пользователя');
  }
});

app.delete('/users/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await User.findByIdAndDelete(id);
    const users = await User.find(); 
    res.json(users);
  } catch (error) {
    res.status(500).send('Ошибка при удалении пользователя');
  }
});

app.put('/users/:id', async (req, res) => {
  const { id } = req.params;
  const { name, age, email } = req.body;
  try {
    const updatedUser = await User.findByIdAndUpdate(id, { name, age, email }, { new: true });
    const users = await User.find();  
    res.json(users);
  } catch (error) {
    res.status(500).send('Ошибка при обновлении данных пользователя');
  }
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
  console.log(`Сервер работает на порту ${port}`);
});

const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/views/index.html');
});

app.post('/greet', (req, res) => {
    const name = req.body.name;
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Your Greeting</title>
            <link rel="stylesheet" href="/style.css">
        </head>
        <body>
            <h1>Your Personalized Greeting</h1>
            <p>Hello, ${name}! Nice to meet you!</p>
            <a href="/">Go back</a> 
        </body>
        </html>
    `);
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

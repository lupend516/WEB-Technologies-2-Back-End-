// server.js
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const path = require('path');
const bcrypt = require('bcrypt');
const User = require('./models/User');
const authRoutes = require('./routes/auth');

const app = express();

// Подключение к MongoDB Atlas
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Успешное подключение к MongoDB Atlas'))
  .catch(err => console.error('Ошибка подключения к MongoDB Atlas:', err));

// Настройка сессий
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Для тестирования на localhost
}));

// Middleware для обработки JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware для статических файлов (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'views')));

// Маршрут для корневого пути (регистрация и вход)
app.get('/', (req, res) => {
  res.send(`
    <h1>Добро пожаловать в приложение 2FA!</h1>
    <form action='/register' method='POST'>
      <input type='text' name='username' placeholder='Введите имя пользователя' required />
      <input type='password' name='password' placeholder='Введите пароль' required />
      <button type='submit'>Зарегистрироваться</button>
    </form>
    <form action='/login' method='POST'>
      <input type='text' name='username' placeholder='Введите имя пользователя' required />
      <input type='password' name='password' placeholder='Введите пароль' required />
      <button type='submit'>Войти</button>
    </form>
  `);
});

// Регистрация пользователя
app.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const user = new User({ username, password: hashedPassword });
    await user.save();
    req.session.userId = user._id;
    res.redirect('/setup-2fa-page');
  } catch (error) {
    res.status(500).send('Ошибка регистрации');
  }
});

// Вход пользователя
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });
    if (user && await bcrypt.compare(password, user.password)) {
      req.session.userId = user._id;
      res.redirect('/setup-2fa-page');
    } else {
      res.status(401).send('Неверные учетные данные');
    }
  } catch (error) {
    res.status(500).send('Ошибка входа');
  }
});

// Проверка авторизации
const requireAuth = (req, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Не авторизован' });
  }
  next();
};

// Маршрут для отдачи HTML-страницы настройки 2FA (только для авторизованных пользователей)
app.get('/setup-2fa-page', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'setup-2fa.html'));
});

// Подключение маршрутов
app.use('/auth', authRoutes);

// Запуск сервера
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});

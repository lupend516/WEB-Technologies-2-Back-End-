// models/User.js
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  twoFASecret: { type: String }, // Секретный ключ для 2FA
  is2FAEnabled: { type: Boolean, default: false } // Флаг, указывающий, включена ли 2FA
});

module.exports = mongoose.model('User', userSchema);
// routes/auth.js
const express = require('express');
const router = express.Router();
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const User = require('../models/User');

// Маршрут для настройки 2FA
router.get('/setup-2fa', async (req, res) => {
  // Временно создаем пользователя для тестирования
  let user = await User.findOne({ username: 'testuser' });
  if (!user) {
    user = new User({ username: 'testuser', password: 'testpassword' });
    await user.save();
  }

  req.session.userId = user._id; // Сохраняем ID пользователя в сессии

  // Генерация секретного ключа
  const secret = speakeasy.generateSecret({ length: 20 });
  user.twoFASecret = secret.base32;
  await user.save();

  // Генерация QR-кода
  qrcode.toDataURL(secret.otpauth_url, (err, data_url) => {
    if (err) {
      return res.status(500).send('Ошибка генерации QR-кода');
    }

    // Отправка QR-кода на фронтенд
    res.json({ qrCode: data_url });
  });
});

// Маршрут для проверки OTP
router.post('/verify-otp', async (req, res) => {
  const { otp } = req.body;
  const user = await User.findById(req.session.userId);

  // Верификация OTP
  const verified = speakeasy.totp.verify({
    secret: user.twoFASecret,
    encoding: 'base32',
    token: otp
  });

  if (verified) {
    user.is2FAEnabled = true;
    await user.save();
    res.send('2FA успешно активирована!');
  } else {
    res.status(400).send('Неверный OTP');
  }
});

module.exports = router;
const express = require("express"); // Подключаем Express
const connectDB = require("./config/db"); // Импортируем функцию подключения к базе данных
const session = require("express-session"); // Подключаем express-session для управления сессиями пользователей
const authRoutes = require("./routes/authRoutes"); // Импортируем маршруты для аутентификации
const path = require("path"); // Подключаем path для работы с файловыми путями
require("dotenv").config(); // Загружаем переменные окружения из .env файла

const app = express(); // Создаем экземпляр Express
app.set("view engine", "ejs"); // Устанавливаем EJS как шаблонизатор

// Подключаем статические файлы (CSS, изображения, JS)
app.use(express.static(path.join(__dirname, "public")));

// Встроенные middleware для обработки JSON и URL-кодированных данных
app.use(express.json()); // Позволяет работать с JSON-данными в запросах
app.use(express.urlencoded({ extended: true })); // Разбирает URL-encoded данные из форм

// Настройка сессий (хранение данных пользователя между запросами)
app.use(
  session({
    secret: process.env.SESSION_SECRET || "my_secret_key", // Секретный ключ для шифрования данных сессии
    resave: false, // Отключаем пересохранение сессии, если данные не изменились
    saveUninitialized: false, // Не сохраняем пустые сессии
  })
);

// Подключаем маршруты для аутентификации (регистрация, вход, выход и т. д.)
app.use("/", authRoutes);

// Подключаемся к базе данных MongoDB
connectDB();

// Маршрут для проверки работы сервера
app.get("/", (req, res) => {
  res.send("API is running...");
});

// Запуск сервера на указанном порту
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Сервер запущен на порту ${PORT}`));
